const mysql = require('mysql2/promise');
const prompt = require('prompt-sync');

async function main(){
    let connection;
    try {
        const dbConfig = {
            host: 'localhost',
            user: 'root',
            password: 'root',
            port: 3307,
            database: 'locadora'
        }       
        connection = await mysql.createConnection(dbConfig);
        console.log('Conexão ativa');
    } catch(err){
        console.error('Erro DB: ',err);
    }
}

main();